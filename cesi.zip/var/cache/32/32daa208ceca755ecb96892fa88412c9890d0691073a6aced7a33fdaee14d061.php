<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Article/show.html.twig */
class __TwigTemplate_d0a5737d691270faa96a830e129e0f482c4b4de8e8b91cf14dec0f1aef4d3b96 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "Article/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <h1>Détail de l'article</h1>
    <p>";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Titre", [], "any", false, false, false, 5), "html", null, true);
        echo "</p>
    <p>";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Description", [], "any", false, false, false, 6), "html", null, true);
        echo "</p>
    <p>";
        // line 7
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Auteur", [], "any", false, false, false, 7), "html", null, true);
        echo "</p>
    <p><a href=\"/article/update/";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Id", [], "any", false, false, false, 8), "html", null, true);
        echo "\"> Modifier ce super Article </a></p>
    <p><a href=\"/article/delete/";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Id", [], "any", false, false, false, 9), "html", null, true);
        echo "\"> Supprimer ce super Article </a></p>
    ";
        // line 10
        if ((0 !== twig_compare(($context["categorie"] ?? null), null))) {
            // line 11
            echo "    <h2>Catégorie</h2>
    <p>";
            // line 12
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["categorie"] ?? null), "libelle", [], "any", false, false, false, 12), "html", null, true);
            echo "</p>
    <p>";
            // line 13
            echo twig_get_attribute($this->env, $this->source, ($context["categorie"] ?? null), "icon", [], "any", false, false, false, 13);
            echo "</p>
    ";
        }
        // line 15
        echo "    ";
        if ((1 === twig_compare(twig_length_filter($this->env, ($context["commentaires"] ?? null)), 0))) {
            // line 16
            echo "<h2>Commentaires</h2>
        <div class=\"row\">
            ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["commentaires"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["commentaire"]) {
                // line 19
                echo "<div class=\"col-2\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["commentaire"], "Auteur", [], "any", false, false, false, 19), "html", null, true);
                echo "</div>
                <div class=\"col-3\">";
                // line 20
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["commentaire"], "Texte", [], "any", false, false, false, 20), "html", null, true);
                echo "</div>
                <div class=\"col-2\">";
                // line 21
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["commentaire"], "Mail", [], "any", false, false, false, 21), "html", null, true);
                echo "</div>
                <div class=\"col-2\">";
                // line 22
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["commentaire"], "date", [], "any", false, false, false, 22), "d/m/Y"), "html", null, true);
                echo "</div>
                <div class=\"col-3\">

                    <a href=\"/commentaire/update/";
                // line 25
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["commentaire"], "id", [], "any", false, false, false, 25), "html", null, true);
                echo "\">
                        Modifier
                    </a> | <a href=\"/commentaire/delete/";
                // line 27
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["commentaire"], "id", [], "any", false, false, false, 27), "html", null, true);
                echo "\">
                        Supprimer
                    </a>
                    
                </div>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['commentaire'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "        </div>";
        } else {
            // line 35
            echo "<div>
            <div>Aucun commentaire sur cet article.</div>
            <a class=\"btn btn-primary\" href=\"/Commentaire/Add/";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "id", [], "any", false, false, false, 37), "html", null, true);
            echo "\">Ajouter un commentaire</a>
        </div>";
        }
    }

    public function getTemplateName()
    {
        return "Article/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 37,  136 => 35,  133 => 33,  122 => 27,  117 => 25,  111 => 22,  107 => 21,  103 => 20,  98 => 19,  94 => 18,  90 => 16,  87 => 15,  82 => 13,  78 => 12,  75 => 11,  73 => 10,  69 => 9,  65 => 8,  61 => 7,  57 => 6,  53 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block body %}
    <h1>Détail de l'article</h1>
    <p>{{ article.Titre }}</p>
    <p>{{ article.Description }}</p>
    <p>{{ article.Auteur }}</p>
    <p><a href=\"/article/update/{{ article.Id }}\"> Modifier ce super Article </a></p>
    <p><a href=\"/article/delete/{{ article.Id }}\"> Supprimer ce super Article </a></p>
    {% if categorie != null %}
    <h2>Catégorie</h2>
    <p>{{categorie.libelle}}</p>
    <p>{{categorie.icon|raw}}</p>
    {% endif %}
    {% if commentaires|length > 0 -%}
        <h2>Commentaires</h2>
        <div class=\"row\">
            {% for commentaire in commentaires -%}
                <div class=\"col-2\">{{commentaire.Auteur}}</div>
                <div class=\"col-3\">{{commentaire.Texte}}</div>
                <div class=\"col-2\">{{commentaire.Mail}}</div>
                <div class=\"col-2\">{{commentaire.date|date('d/m/Y')}}</div>
                <div class=\"col-3\">

                    <a href=\"/commentaire/update/{{ commentaire.id }}\">
                        Modifier
                    </a> | <a href=\"/commentaire/delete/{{ commentaire.id }}\">
                        Supprimer
                    </a>
                    
                </div>
            {%- endfor %}
        </div>
    {%- else -%}
        <div>
            <div>Aucun commentaire sur cet article.</div>
            <a class=\"btn btn-primary\" href=\"/Commentaire/Add/{{ article.id }}\">Ajouter un commentaire</a>
        </div>
    {%- endif %}
{% endblock %}", "Article/show.html.twig", "C:\\dev\\www\\cesi\\templates\\Article\\show.html.twig");
    }
}
