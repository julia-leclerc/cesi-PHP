<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Article/update.html.twig */
class __TwigTemplate_853e742ed97d15edbbae62793d3a73760ae86a962f005849592255f3c0e798a6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "Article/update.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <h1>Modification de l'article \"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Titre", [], "any", false, false, false, 4), "html", null, true);
        echo "\"</h1>
    <form method=\"post\">
        <input type=\"text\" name=\"Titre\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Titre", [], "any", false, false, false, 6), "html", null, true);
        echo "\">
        <textarea name=\"Description\">
            ";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Description", [], "any", false, false, false, 8), "html", null, true);
        echo "
        </textarea>
        <input type=\"date\" name=\"DateAjout\" value=\"";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "DateAjout", [], "any", false, false, false, 10), "html", null, true);
        echo "\">
        <select name=\"Auteur\">
            ";
        // line 12
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Auteur", [], "any", false, false, false, 12), "Rebecca"))) {
            // line 13
            echo "                <option selected>Rebecca</option>
            ";
        } else {
            // line 15
            echo "                <option >Rebecca</option>
            ";
        }
        // line 17
        echo "
            ";
        // line 18
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Auteur", [], "any", false, false, false, 18), "Alexandre"))) {
            // line 19
            echo "                <option selected>Alexandre</option>
            ";
        } else {
            // line 21
            echo "                <option >Alexandre</option>
            ";
        }
        // line 23
        echo "
            ";
        // line 24
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Auteur", [], "any", false, false, false, 24), "Emilie"))) {
            // line 25
            echo "                <option selected>Emilie</option>
            ";
        } else {
            // line 27
            echo "                <option >Emilie</option>
            ";
        }
        // line 29
        echo "
            ";
        // line 30
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Auteur", [], "any", false, false, false, 30), "Léo"))) {
            // line 31
            echo "                <option selected>Léo</option>
            ";
        } else {
            // line 33
            echo "                <option >Léo</option>
            ";
        }
        // line 35
        echo "
            ";
        // line 36
        if ((0 === twig_compare(twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "Auteur", [], "any", false, false, false, 36), "Aegir"))) {
            // line 37
            echo "                <option selected>Aegir</option>
            ";
        } else {
            // line 39
            echo "                <option >Aegir</option>
            ";
        }
        // line 41
        echo "
        </select>
        <input type=\"submit\" value=\"Enregistrer les modifications\">
    </form>

";
    }

    public function getTemplateName()
    {
        return "Article/update.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 41,  129 => 39,  125 => 37,  123 => 36,  120 => 35,  116 => 33,  112 => 31,  110 => 30,  107 => 29,  103 => 27,  99 => 25,  97 => 24,  94 => 23,  90 => 21,  86 => 19,  84 => 18,  81 => 17,  77 => 15,  73 => 13,  71 => 12,  66 => 10,  61 => 8,  56 => 6,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block body %}
    <h1>Modification de l'article \"{{ article.Titre }}\"</h1>
    <form method=\"post\">
        <input type=\"text\" name=\"Titre\" value=\"{{ article.Titre }}\">
        <textarea name=\"Description\">
            {{ article.Description }}
        </textarea>
        <input type=\"date\" name=\"DateAjout\" value=\"{{ article.DateAjout }}\">
        <select name=\"Auteur\">
            {% if article.Auteur == \"Rebecca\" %}
                <option selected>Rebecca</option>
            {% else %}
                <option >Rebecca</option>
            {% endif %}

            {% if article.Auteur == \"Alexandre\" %}
                <option selected>Alexandre</option>
            {% else %}
                <option >Alexandre</option>
            {% endif %}

            {% if article.Auteur == \"Emilie\" %}
                <option selected>Emilie</option>
            {% else %}
                <option >Emilie</option>
            {% endif %}

            {% if article.Auteur == \"Léo\" %}
                <option selected>Léo</option>
            {% else %}
                <option >Léo</option>
            {% endif %}

            {% if article.Auteur == \"Aegir\" %}
                <option selected>Aegir</option>
            {% else %}
                <option >Aegir</option>
            {% endif %}

        </select>
        <input type=\"submit\" value=\"Enregistrer les modifications\">
    </form>

{% endblock %}", "Article/update.html.twig", "C:\\dev\\www\\cesi\\templates\\Article\\update.html.twig");
    }
}
