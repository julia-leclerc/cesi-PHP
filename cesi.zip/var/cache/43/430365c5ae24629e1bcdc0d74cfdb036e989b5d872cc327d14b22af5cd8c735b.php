<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Article/all.html.twig */
class __TwigTemplate_dfe46929c409a5965736c8c70dd1f4fb45f722ac6b2e9c3b2987ce65ded75467 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "Article/all.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 3
        echo "    Liste article >> ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 7
        echo "    <h1>Voici la liste des articles</h1>
    <div class=\"row\">
    ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["articleList"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
            // line 10
            echo "        <div class=\"col-sm-3\">
            <div class=\"card\" style=\"width: 18rem;\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">";
            // line 13
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "Titre", [], "any", false, false, false, 13), "html", null, true);
            echo "</h5>
                    <p class=\"card-text\">
                        ";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "getShortDesc", [0 => 3], "method", false, false, false, 15), "html", null, true);
            echo "
                        <br/>
                        Ecrit le ";
            // line 17
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "DateAjout", [], "any", false, false, false, 17), "d/m/Y"), "html", null, true);
            echo "
                    </p>
                    <a href=\"/Article/Show/";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "id", [], "any", false, false, false, 19), "html", null, true);
            echo "\" class=\"btn btn-primary\">
                        Consulter
                    </a>
                </div>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "Article/all.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 26,  90 => 19,  85 => 17,  80 => 15,  75 => 13,  70 => 10,  66 => 9,  62 => 7,  58 => 6,  51 => 3,  47 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% block title %}
    Liste article >> {{ parent() }}
{% endblock %}

{% block body %}
    <h1>Voici la liste des articles</h1>
    <div class=\"row\">
    {% for article in articleList %}
        <div class=\"col-sm-3\">
            <div class=\"card\" style=\"width: 18rem;\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">{{ article.Titre }}</h5>
                    <p class=\"card-text\">
                        {{ article.getShortDesc(3) }}
                        <br/>
                        Ecrit le {{ article.DateAjout|date(\"d/m/Y\") }}
                    </p>
                    <a href=\"/Article/Show/{{ article.id }}\" class=\"btn btn-primary\">
                        Consulter
                    </a>
                </div>
            </div>
        </div>
    {% endfor %}
    </div>
{% endblock %}", "Article/all.html.twig", "C:\\dev\\www\\cesi\\templates\\Article\\all.html.twig");
    }
}
