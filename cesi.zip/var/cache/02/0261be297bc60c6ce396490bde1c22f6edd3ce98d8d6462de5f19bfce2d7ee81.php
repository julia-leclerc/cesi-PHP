<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Categorie/all.html.twig */
class __TwigTemplate_5662aaae714b3e795eb4bea79f5f952b7222b838b782e396c73bd0facdecf6b2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "Categorie/all.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 3
        echo "    Liste article >> ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 7
        echo "    <h1>Voici la liste des articles</h1>
    <div class=\"row\">
    ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["categorie"]) {
            // line 10
            echo "        <div class=\"col-sm-3\">
            <div class=\"card\" style=\"width: 18rem;\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">";
            // line 13
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["categorie"], "libelle", [], "any", false, false, false, 13), "html", null, true);
            echo "</h5>               
                    <p>";
            // line 14
            echo twig_get_attribute($this->env, $this->source, $context["categorie"], "icon", [], "any", false, false, false, 14);
            echo "</p>     
                    <a href=\"/Categorie/Show/";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["categorie"], "id", [], "any", false, false, false, 15), "html", null, true);
            echo "\" class=\"btn btn-primary\">
                        Consulter
                    </a>
                </div>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['categorie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "Categorie/all.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 22,  83 => 15,  79 => 14,  75 => 13,  70 => 10,  66 => 9,  62 => 7,  58 => 6,  51 => 3,  47 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% block title %}
    Liste article >> {{ parent() }}
{% endblock %}

{% block body %}
    <h1>Voici la liste des articles</h1>
    <div class=\"row\">
    {% for categorie in categories %}
        <div class=\"col-sm-3\">
            <div class=\"card\" style=\"width: 18rem;\">
                <div class=\"card-body\">
                    <h5 class=\"card-title\">{{ categorie.libelle }}</h5>               
                    <p>{{categorie.icon|raw}}</p>     
                    <a href=\"/Categorie/Show/{{ categorie.id }}\" class=\"btn btn-primary\">
                        Consulter
                    </a>
                </div>
            </div>
        </div>
    {% endfor %}
    </div>
{% endblock %}", "Categorie/all.html.twig", "C:\\dev\\www\\cesi\\templates\\Categorie\\all.html.twig");
    }
}
