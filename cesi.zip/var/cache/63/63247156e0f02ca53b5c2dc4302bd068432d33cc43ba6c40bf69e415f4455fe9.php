<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Commentaire/form.html.twig */
class __TwigTemplate_70b7fac35d949c3a9cfd45d8988c23e7e036d882fb496afc8d5ab5a91bed78aa extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "Commentaire/form.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        if (array_key_exists("commentaire", $context)) {
            // line 5
            echo "<h3>Modification du commentaire \"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["commentaire"] ?? null), "texte", [], "any", false, false, false, 5), "html", null, true);
            echo "\"</h3>";
        } else {
            // line 7
            echo "<h3>Ajout d'un nouveau commentaire</h3>";
        }
        // line 9
        echo "
    <form method=\"post\">
        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">Article :</label>
            <input class=\"col-8\" type=\"text\" disabled value=\"";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["article"] ?? null), "titre", [], "any", false, false, false, 13), "html", null, true);
        echo "\">
        </div>
        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">Commentaire :</label>
            <textarea class=\"col-8\" name=\"texte\">";
        // line 18
        if (array_key_exists("commentaire", $context)) {
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["commentaire"] ?? null), "texte", [], "any", false, false, false, 19), "html", null, true);
        }
        // line 21
        echo "</textarea>
        </div>

        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">Auteur :</label>
            <input class=\"col-8\" type=\"text\" name=\"auteur\"";
        // line 27
        if (array_key_exists("commentaire", $context)) {
            echo "value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["commentaire"] ?? null), "auteur", [], "any", false, false, false, 27), "html", null, true);
            echo "\"";
        }
        echo ">
        </div>

        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">E-mail :</label>
            <input class=\"col-8\" type=\"email\" name=\"mail\"";
        // line 33
        if (array_key_exists("commentaire", $context)) {
            echo "value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["commentaire"] ?? null), "mail", [], "any", false, false, false, 33), "html", null, true);
            echo "\"";
        }
        echo ">
        </div>

        <div class=\"row my-2\">
            <span class=\"col-4\"></span>
            <input type=\"submit\" value=\"Enregistrer les modifications\">
        </div>
    </form>
";
    }

    public function getTemplateName()
    {
        return "Commentaire/form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 33,  86 => 27,  79 => 21,  76 => 19,  74 => 18,  67 => 13,  61 => 9,  58 => 7,  53 => 5,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block body %}
    {% if commentaire is defined -%}
        <h3>Modification du commentaire \"{{ commentaire.texte }}\"</h3>
    {%- else -%}
        <h3>Ajout d'un nouveau commentaire</h3>
    {%- endif %}

    <form method=\"post\">
        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">Article :</label>
            <input class=\"col-8\" type=\"text\" disabled value=\"{{ article.titre }}\">
        </div>
        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">Commentaire :</label>
            <textarea class=\"col-8\" name=\"texte\">
                {%- if commentaire is defined -%}
                    {{ commentaire.texte }}
                {%- endif -%}
            </textarea>
        </div>

        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">Auteur :</label>
            <input class=\"col-8\" type=\"text\" name=\"auteur\"
                   {%- if commentaire is defined -%} value=\"{{ commentaire.auteur }}\"{%- endif -%}>
        </div>

        <div class=\"row my-2\">
            <label class=\"col-4 text-right pr-2\">E-mail :</label>
            <input class=\"col-8\" type=\"email\" name=\"mail\"
                   {%- if commentaire is defined -%} value=\"{{ commentaire.mail }}\"{%- endif -%}>
        </div>

        <div class=\"row my-2\">
            <span class=\"col-4\"></span>
            <input type=\"submit\" value=\"Enregistrer les modifications\">
        </div>
    </form>
{% endblock %}", "Commentaire/form.html.twig", "C:\\dev\\www\\cesi\\templates\\Commentaire\\form.html.twig");
    }
}
